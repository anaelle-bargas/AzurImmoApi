package bts.sio.azurimmo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bts.sio.azurimmo.model.Associe;

public interface AssocieRepository extends JpaRepository<Associe, Long>{
}
